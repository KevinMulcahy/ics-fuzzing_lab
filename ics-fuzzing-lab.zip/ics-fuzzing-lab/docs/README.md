# ICS Fuzzing Lab

This README will be populated with content from 'ics lab readme.docx'.