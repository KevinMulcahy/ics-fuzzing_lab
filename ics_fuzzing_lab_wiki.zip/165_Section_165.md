#### Install Tcpreplay and Analysis Tools
```bash
# Install tcpreplay
sudo apt install -y tcpreplay