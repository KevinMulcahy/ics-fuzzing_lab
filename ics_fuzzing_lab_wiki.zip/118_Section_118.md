# Plan deployment
terraform plan