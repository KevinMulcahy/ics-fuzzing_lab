# Install and configure auditd
sudo apt install -y auditd
sudo systemctl enable auditd
sudo systemctl start auditd