# Check storage usage
echo "Storage Usage:"
pvesm status