# Remove OS kernel (after reboot)
apt remove linux-image-amd64 'linux-image-6.1*'
update-grub
```