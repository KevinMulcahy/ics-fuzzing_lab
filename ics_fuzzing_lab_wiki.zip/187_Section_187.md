### Logging and Monitoring
```bash
# Configure rsyslog for centralized logging
echo "*.* @@192.168.122.20:514" | sudo tee -a /etc/rsyslog.conf
sudo systemctl restart rsyslog