# Allow SSH from management network only
sudo ufw allow from 192.168.122.0/24 to any port 22