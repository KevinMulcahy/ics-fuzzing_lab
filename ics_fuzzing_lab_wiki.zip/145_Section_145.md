#### Install ModbusPal
```bash
# Install Java runtime
sudo apt install -y default-jre