- name: Create simulator launcher scripts
  template:
    src: "{{ item.src }}"
    dest: "/opt/simulators/{{ item.dest }}"
    mode: '0755'
    owner: ubuntu
    group: ubuntu
  loop:
    - { src: 'start-modbuspal.sh.j2', dest: 'start-modbuspal.sh' }
    - { src: 'start-dnp3-sim.sh.j2', dest: 'start-dnp3-sim.sh' }