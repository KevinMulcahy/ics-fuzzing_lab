- name: Configure fuzzing environment variables
  lineinfile:
    path: /home/ubuntu/.bashrc
    line: "{{ item }}"
  loop:
    - 'export AFL_PATH=/opt/fuzzing/AFLplusplus'
    - 'export PATH=$AFL_PATH:$PATH'
    - 'source /opt/fuzzing/boofuzz-env/bin/activate'
```