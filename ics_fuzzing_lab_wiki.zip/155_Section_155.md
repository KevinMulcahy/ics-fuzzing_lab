# Install firmware-mod-kit dependencies
sudo apt install -y git build-essential zlib1g-dev liblzma-dev python-magic