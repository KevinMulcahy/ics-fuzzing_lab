- name: Build AFL++
      make:
        chdir: /opt/fuzzing/AFLplusplus
        jobs: "{{ ansible_processor_vcpus }}"
      become_user: ubuntu