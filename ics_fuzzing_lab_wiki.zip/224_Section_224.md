# Check cluster health
echo "Cluster Status:"
pvecm status