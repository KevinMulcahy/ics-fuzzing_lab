# Check cluster status
pvecm status