# Target Emulation VMs
resource "proxmox_vm_qemu" "target_emulation" {
  count       = 2
  name        = "target-emu-${format("%02d", count.index + 1)}"
  target_node = count.index == 0 ? "pve-fuzzing-01" : "pve-analysis-01"
  vmid        = 601 + count.index
  
  clone    = var.vm_template
  os_type  = "cloud-init"
  cores    = 4
  memory   = 8192
  
  disk {
    slot    = "scsi0"
    size    = "50G"
    type    = "scsi"
    storage = "local-lvm"
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr0"
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr1"
    tag    = 10
  }
  
  ciuser     = "ubuntu"
  cipassword = "fuzzing123"
  sshkeys    = var.ssh_public_key
  ipconfig0  = "ip=10.0.0.${60 + count.index}/24,gw=10.0.0.1"
  ipconfig1  = "ip=10.1.0.${20 + count.index}/24"
  
  tags = "emulation,ubuntu"
}
```