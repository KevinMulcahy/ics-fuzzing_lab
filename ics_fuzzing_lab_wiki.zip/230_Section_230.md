for vm in "${VMS[@]}"; do
    echo "Creating snapshot for VM $vm..."
    qm snapshot $vm $SNAPSHOT_NAME --description "Weekly snapshot $(date)"
done
```