- name: Install OpenDNP3 dependencies
  apt:
    name:
      - cmake
      - build-essential
      - libssl-dev
    state: present