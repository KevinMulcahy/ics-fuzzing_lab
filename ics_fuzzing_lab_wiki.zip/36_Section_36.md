- name: Configure Logstash pipelines
  template:
    src: "{{ item.src }}"
    dest: "/etc/logstash/conf.d/{{ item.dest }}"
  loop:
    - { src: 'fuzzing-logs.conf.j2', dest: 'fuzzing-logs.conf' }
    - { src: 'network-traffic.conf.j2', dest: 'network-traffic.conf' }
    - { src: 'syslog.conf.j2', dest: 'syslog.conf' }
  notify: restart logstash