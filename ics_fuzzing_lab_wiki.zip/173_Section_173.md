Simulation Network (virbr2 - 10.2.0.0/24)
├── Protocol Simulator VMs (10.2.0.10-19)
└── Test Targets (10.2.0.20-29)