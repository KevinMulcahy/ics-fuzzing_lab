- name: Add Elastic repository key
  apt_key:
    url: https://artifacts.elastic.co/GPG-KEY-elasticsearch
    state: present