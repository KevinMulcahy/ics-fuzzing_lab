#### Install ELK Stack
```bash
# Install Java
sudo apt install -y openjdk-11-jdk