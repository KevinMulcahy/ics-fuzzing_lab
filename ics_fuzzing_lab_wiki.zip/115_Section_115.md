output "vm_inventory" {
  description = "Ansible inventory data"
  value = {
    fuzzing_engines = [
      for vm in proxmox_vm_qemu.fuzzing_engines : {
        name = vm.name
        ip   = vm.default_ipv4_address
        vmid = vm.vmid
      }
    ]
    protocol_simulators = [
      for vm in proxmox_vm_qemu.protocol_simulators : {
        name = vm.name
        ip   = vm.default_ipv4_address
        vmid = vm.vmid
      }
    ]
    monitoring = [{
      name = proxmox_vm_qemu.monitoring.name
      ip   = proxmox_vm_qemu.monitoring.default_ipv4_address
      vmid = proxmox_vm_qemu.monitoring.vmid
    }]
  }
}
```