##### Local Storage Configuration
```bash
# Configure local storage for VMs and containers
# Via Web UI: Datacenter > Storage > Add > Directory