##### ZFS Configuration (if using ZFS)
```bash
# Create ZFS pool (example with additional disks)
zpool create -f fuzzing-pool /dev/sdb /dev/sdc
pvesm add zfspool fuzzing-zfs --pool fuzzing-pool --content images,rootdir
```