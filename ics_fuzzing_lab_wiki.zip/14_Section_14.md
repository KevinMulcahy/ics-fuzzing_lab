- name: Clone ICSPFuzzer
  git:
    repo: https://github.com/dark-lbp/isf.git
    dest: /opt/fuzzing/isf
  become_user: ubuntu