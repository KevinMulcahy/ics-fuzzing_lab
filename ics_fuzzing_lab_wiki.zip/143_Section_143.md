# Configure ICSPFuzzer
python2.7 isf.py
```