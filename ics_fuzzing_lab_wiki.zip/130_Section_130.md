##### Ansible Configuration
```ini
# ansible.cfg
[defaults]
inventory = terraform_inventory.py
remote_user = ubuntu
private_key_file = ~/.ssh/id_rsa
host_key_checking = False
gather_facts = True
retry_files_enabled = False