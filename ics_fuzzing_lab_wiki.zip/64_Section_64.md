#### 2. BIOS/UEFI Configuration
- Enable virtualization features (VT-x, VT-d)
- Configure boot order
- Set up RAID configurations
- Enable IPMI/remote management