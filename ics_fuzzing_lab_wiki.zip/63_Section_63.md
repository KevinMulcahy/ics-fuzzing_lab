#### 1. Physical Setup
```bash
# Document hardware specifications
- Record serial numbers
- Document network MAC addresses
- Configure iDRAC/remote management
- Install additional RAM/storage if needed
```