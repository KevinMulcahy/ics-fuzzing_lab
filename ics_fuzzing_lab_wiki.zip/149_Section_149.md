# Clone and build OpenDNP3
git clone --recursive https://github.com/automatak/dnp3.git
cd dnp3
mkdir build && cd build
cmake .. -DDNP3_ALL=ON
make -j$(nproc)
sudo make install
```