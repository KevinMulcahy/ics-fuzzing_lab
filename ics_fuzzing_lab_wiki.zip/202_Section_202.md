for vm in "${VMS[@]}"; do
    echo "Testing VM $vm..."
    status=$(qm status $vm | grep -o "status: [a-z]*" | cut -d' ' -f2)
    if [ "$status" = "running" ]; then
        echo "✓ VM $vm is running"
        # Test SSH connectivity if possible
        ip=$(qm guest cmd $vm network-get-interfaces 2>/dev/null | grep -o '"ip-address":"[^"]*"' | head -1 | cut -d'"' -f4)
        if [ ! -z "$ip" ]; then
            echo "  IP: $ip"
        fi
    else
        echo "✗ VM $vm is $status"
    fi
done