- name: Download ModbusPal
  get_url:
    url: https://github.com/zeronone/ModbusPal/releases/download/v1.6/ModbusPal.jar
    dest: /opt/simulators/ModbusPal.jar
    owner: ubuntu
    group: ubuntu
    mode: '0644'