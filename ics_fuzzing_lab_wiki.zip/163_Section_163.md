# Install Logstash
sudo apt install -y logstash
sudo systemctl enable logstash.service
sudo systemctl start logstash.service
```