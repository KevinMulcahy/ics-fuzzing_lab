- name: Build OpenDNP3
      make:
        chdir: /opt/simulators/dnp3/build
        jobs: "{{ ansible_processor_vcpus }}"
      become_user: ubuntu