#### Install AFL++
```bash
# Install build dependencies
sudo apt install -y build-essential python3-dev automake cmake git flex bison libglib2.0-dev libpixman-1-dev