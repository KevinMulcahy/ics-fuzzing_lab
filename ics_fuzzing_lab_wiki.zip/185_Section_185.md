# Allow libvirt networks
sudo ufw allow from 10.1.0.0/24
sudo ufw allow from 10.2.0.0/24
sudo ufw allow from 10.3.0.0/24