###### Main Site Playbook (playbooks/site.yml)
```yaml
---
- name: Configure all fuzzing lab systems
  hosts: all
  become: yes
  gather_facts: yes
  vars:
    ssh_public_key: "{{ lookup('file', '~/.ssh/id_rsa.pub') }}"
  
  roles:
    - common
    - security