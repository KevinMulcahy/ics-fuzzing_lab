# Create virtual environment
python3 -m venv ~/boofuzz-env
source ~/boofuzz-env/bin/activate