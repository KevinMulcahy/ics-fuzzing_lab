# Test VM network connectivity
VMS=(101 102 201 202 301 401 501 601 602 701)