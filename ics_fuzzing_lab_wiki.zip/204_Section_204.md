#### VM Resource Test
```bash
#!/bin/bash
# test-vm-resources.sh