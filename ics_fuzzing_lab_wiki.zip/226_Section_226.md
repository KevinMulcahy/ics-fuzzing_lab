# Check VM status
echo "VM Status:"
qm list