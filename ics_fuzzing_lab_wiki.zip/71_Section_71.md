# Node name: pve-analysis-01
# IP: 192.168.1.11/24
# Join cluster: fuzzing-cluster
```