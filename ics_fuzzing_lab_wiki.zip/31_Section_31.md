- name: Install Elasticsearch
  apt:
    name: elasticsearch
    state: present