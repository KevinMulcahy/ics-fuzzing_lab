# Create launcher
sudo ln -s /opt/ghidra/ghidraRun /usr/local/bin/ghidra
```