# Verify installation
afl-fuzz -h
```