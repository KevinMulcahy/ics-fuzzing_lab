#### Dell PowerEdge R730 (Secondary/Analysis Server) - Proxmox Node 2
```bash
# Install Proxmox VE 8.x  
# Similar partitioning scheme
# Configure as secondary cluster node