###### Outputs Configuration
```hcl
# outputs.tf
output "fuzzing_engine_ips" {
  description = "IP addresses of fuzzing engine VMs"
  value = {
    for vm in proxmox_vm_qemu.fuzzing_engines : vm.name => {
      management = vm.default_ipv4_address
      fuzzing    = "10.1.0.${10 + index(proxmox_vm_qemu.fuzzing_engines, vm)}"
    }
  }
}