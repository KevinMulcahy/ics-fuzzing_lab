# Create launch script
cat << 'EOF' > ~/start-modbuspal.sh
#!/bin/bash
java -jar ~/ModbusPal.jar
EOF
chmod +x ~/start-modbuspal.sh
```