- name: Configure sysctl for performance
  sysctl:
    name: "{{ item.name }}"
    value: "{{ item.value }}"
    state: present
    reload: yes
  loop:
    - { name: 'net.core.rmem_max', value: '134217728' }
    - { name: 'net.core.wmem_max', value: '134217728' }
    - { name: 'net.ipv4.tcp_rmem', value: '4096 87380 134217728' }
    - { name: 'net.ipv4.tcp_wmem', value: '4096 65536 134217728' }
```