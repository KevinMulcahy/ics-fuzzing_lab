##### Join Secondary Server (R430)
```bash
# Join cluster from secondary server
pvecm add [PRIMARY-SERVER-IP]
```