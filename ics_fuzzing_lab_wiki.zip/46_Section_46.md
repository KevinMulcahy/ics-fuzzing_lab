- name: Configure PCAP replay systems
  hosts: pcap_replay
  become: yes
  roles:
    - pcap_tools
```