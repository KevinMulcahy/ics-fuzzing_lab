- name: Create simulators directory
  file:
    path: /opt/simulators
    state: directory
    owner: ubuntu
    group: ubuntu
    mode: '0755'