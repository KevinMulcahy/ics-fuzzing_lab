Fuzzing Network (virbr1 - 10.1.0.0/24)
├── Fuzzing Engine VMs (10.1.0.10-19)
├── Target Emulation VMs (10.1.0.20-29)
└── PCAP Replay VMs (10.1.0.30-39)