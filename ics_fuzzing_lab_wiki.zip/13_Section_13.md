- name: Install ICSPFuzzer dependencies
  apt:
    name:
      - python2.7
      - python2.7-dev
    state: present