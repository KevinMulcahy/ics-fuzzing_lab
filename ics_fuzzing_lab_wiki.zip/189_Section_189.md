# Configure logrotate
sudo cat << 'EOF' > /etc/logrotate.d/fuzzinglab
/var/log/fuzzinglab/*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    create 0644 root root
}
EOF
```