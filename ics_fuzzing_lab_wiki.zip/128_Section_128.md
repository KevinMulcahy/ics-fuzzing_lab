def main():
    inventory = {
        'fuzzing_engines': {'hosts': []},
        'protocol_simulators': {'hosts': []},
        'monitoring': {'hosts': []},
        'reverse_engineering': {'hosts': []},
        'pcap_replay': {'hosts': []},
        'target_emulation': {'hosts': []},
        '_meta': {'hostvars': {}}
    }
    
    terraform_data = get_terraform_output()
    
    if terraform_data:
        # Process fuzzing engines
        for vm in terraform_data.get('fuzzing_engines', []):
            hostname = vm['name']
            inventory['fuzzing_engines']['hosts'].append(hostname)
            inventory['_meta']['hostvars'][hostname] = {
                'ansible_host': vm['ip'],
                'vmid': vm['vmid']
            }
        
        # Process other VM types similarly...
    
    print(json.dumps(inventory, indent=2))