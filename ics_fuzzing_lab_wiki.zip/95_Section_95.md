| VM Type | Count | vCPU | RAM (GB) | Disk (GB) | OS | Primary Tools |
|---------|-------|------|----------|-----------|-----|---------------|
| Fuzzing Engine | 2-3 | 4-8 | 8-16 | 100 | Ubuntu 22.04 | Boofuzz, AFL++, ICSPFuzzer |
| Protocol Simulator | 2-3 | 2-4 | 4-8 | 50 | Ubuntu/Windows | ModbusPal, OpenDNP3 |
| Reverse Engineering | 1-2 | 4-8 | 16-32 | 200 | Ubuntu 22.04 | Ghidra, IDA Pro |
| Monitoring/Logging | 1 | 4 | 8 | 500 | Ubuntu 22.04 | ELK Stack |
| PCAP Replay | 1-2 | 2-4 | 4-8 | 100 | Ubuntu 22.04 | Tcpreplay, Scapy |
| Target Emulation | 2-4 | 2-4 | 4-8 | 50 | Ubuntu 22.04 | QEMU, Docker |
| Management | 1 | 2 | 4 | 50 | Ubuntu 22.04 | Ansible, Terraform |