- name: Configure fuzzing engine systems
  hosts: fuzzing_engines
  become: yes
  roles:
    - fuzzing_tools