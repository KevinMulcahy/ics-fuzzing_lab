###### Protocol Simulators Role (roles/protocol_simulators/tasks/main.yml)
```yaml
---
- name: Install Java runtime for ModbusPal
  apt:
    name: default-jre
    state: present