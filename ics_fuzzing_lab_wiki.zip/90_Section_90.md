##### Create Cluster on Primary Server (R730)
```bash
# Create cluster
pvecm create fuzzing-cluster