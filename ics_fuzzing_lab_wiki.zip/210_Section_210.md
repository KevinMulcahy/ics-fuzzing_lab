# Test Boofuzz
python3 -c "import boofuzz; print('✓ Boofuzz OK')" 2>/dev/null || echo "✗ Boofuzz FAIL"