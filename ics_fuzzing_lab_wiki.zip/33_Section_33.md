- name: Install Kibana
  apt:
    name: kibana
    state: present