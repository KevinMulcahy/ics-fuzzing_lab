##### Method 1: ISO Installation (Recommended)
```bash
# Download Proxmox VE 8.x ISO from https://www.proxmox.com/downloads
# Boot from ISO and follow installation wizard