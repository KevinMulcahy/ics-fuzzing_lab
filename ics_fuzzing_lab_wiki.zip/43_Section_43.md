- name: Configure protocol simulator systems  
  hosts: protocol_simulators
  become: yes
  roles:
    - protocol_simulators