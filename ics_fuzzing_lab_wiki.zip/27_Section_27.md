- name: Enable simulator services
  systemd:
    name: "{{ item }}"
    enabled: yes
    daemon_reload: yes
  loop:
    - modbuspal
    - dnp3-sim
```