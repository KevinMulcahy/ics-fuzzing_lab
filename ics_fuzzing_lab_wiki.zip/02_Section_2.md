###### Common Role (roles/common/tasks/main.yml)
```yaml
---
- name: Update system packages
  apt:
    update_cache: yes
    upgrade: dist
    cache_valid_time: 3600