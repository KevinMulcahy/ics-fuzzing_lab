- name: Download and build AFL++
  block:
    - name: Clone AFL++ repository
      git:
        repo: https://github.com/AFLplusplus/AFLplusplus.git
        dest: /opt/fuzzing/AFLplusplus
        version: stable
      become_user: ubuntu