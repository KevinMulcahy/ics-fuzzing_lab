def get_terraform_output():
    try:
        result = subprocess.run(['terraform', 'output', '-json', 'vm_inventory'], 
                               capture_output=True, text=True, cwd='/opt/terraform')
        return json.loads(result.stdout)
    except:
        return {}