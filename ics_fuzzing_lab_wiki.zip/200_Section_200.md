# Check all VMs status
echo "VM Status:"
qm list