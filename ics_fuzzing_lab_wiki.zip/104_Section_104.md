###### Variables Configuration
```hcl
# variables.tf
variable "proxmox_password" {
  description = "Proxmox API password"
  type        = string
  sensitive   = true
}