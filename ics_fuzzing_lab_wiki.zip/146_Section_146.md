# Download ModbusPal
wget https://github.com/zeronone/ModbusPal/releases/download/v1.6/ModbusPal.jar