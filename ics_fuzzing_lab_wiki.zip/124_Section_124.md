##### Ansible Directory Structure
```
ansible/
├── inventories/
│   ├── production/
│   │   ├── hosts.yml
│   │   └── group_vars/
│   │       ├── fuzzing_engines.yml
│   │       ├── protocol_simulators.yml
│   │       ├── monitoring.yml
│   │       └── all.yml
├── roles/
│   ├── common/
│   ├── fuzzing_tools/
│   ├── protocol_simulators/
│   ├── monitoring/
│   ├── reverse_engineering/
│   └── security/
├── playbooks/
│   ├── site.yml
│   ├── fuzzing_setup.yml
│   ├── monitoring_setup.yml
│   └── security_hardening.yml
└── ansible.cfg
```