# Create terraform.tfvars file
cat << 'EOF' > terraform.tfvars
proxmox_password = "your-proxmox-password"
ssh_public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQ... your-key"
EOF