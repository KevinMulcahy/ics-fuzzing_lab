# Monitoring VM
resource "proxmox_vm_qemu" "monitoring" {
  name        = "monitoring-01"
  target_node = "pve-fuzzing-01"
  vmid        = 401
  
  clone    = var.vm_template
  os_type  = "cloud-init"
  cores    = 4
  memory   = 16384
  
  disk {
    slot    = "scsi0"
    size    = "500G"
    type    = "scsi"
    storage = "local-lvm"
  }
  
  # Multiple network interfaces for monitoring all segments
  network {
    model  = "virtio"
    bridge = "vmbr0"
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr1"
    tag    = 10
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr2"
    tag    = 20
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr3"
    tag    = 30
  }
  
  ciuser     = "ubuntu"
  cipassword = "fuzzing123"
  sshkeys    = var.ssh_public_key
  ipconfig0  = "ip=10.0.0.40/24,gw=10.0.0.1"
  ipconfig1  = "ip=10.1.0.40/24"
  ipconfig2  = "ip=10.2.0.40/24"
  ipconfig3  = "ip=10.3.0.40/24"
  
  tags = "monitoring,ubuntu"
}