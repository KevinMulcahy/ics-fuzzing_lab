# Generate Ansible inventory
terraform output -json vm_inventory > vm_inventory.json
```