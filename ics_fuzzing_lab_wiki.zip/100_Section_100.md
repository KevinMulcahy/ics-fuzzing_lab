# Install Proxmox provider
mkdir -p ~/.terraform.d/plugins
```