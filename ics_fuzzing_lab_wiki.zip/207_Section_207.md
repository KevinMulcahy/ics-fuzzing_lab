for vm in "${VMS[@]}"; do
    echo "VM $vm resources:"
    qm config $vm | grep -E "(memory|cores|net[0-9])"
done
```