variable "vm_template" {
  description = "VM template name"
  type        = string
  default     = "ubuntu-2204-template"
}