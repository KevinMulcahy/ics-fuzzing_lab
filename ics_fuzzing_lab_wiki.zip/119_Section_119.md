# Apply configuration
terraform apply