### Firewall Configuration
```bash
# Install and configure UFW
sudo apt install -y ufw