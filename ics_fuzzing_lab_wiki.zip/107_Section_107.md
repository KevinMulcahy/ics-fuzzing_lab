###### VM Resources Definition
```hcl
# main.tf
# Fuzzing Engine VMs
resource "proxmox_vm_qemu" "fuzzing_engines" {
  count       = 2
  name        = "fuzzing-engine-${format("%02d", count.index + 1)}"
  target_node = count.index == 0 ? "pve-fuzzing-01" : "pve-analysis-01"
  vmid        = 101 + count.index
  
  clone    = var.vm_template
  os_type  = "cloud-init"
  cores    = 8
  memory   = 8192
  balloon  = 4096
  
  disk {
    slot     = "scsi0"
    size     = "100G"
    type     = "scsi"
    storage  = "local-lvm"
    iothread = 1
    cache    = "none"
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr0"
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr1"
    tag    = 10
  }
  
  ciuser     = "ubuntu"
  cipassword = "fuzzing123"
  sshkeys    = var.ssh_public_key
  ipconfig0  = "ip=10.0.0.${10 + count.index}/24,gw=10.0.0.1"
  ipconfig1  = "ip=10.1.0.${10 + count.index}/24"
  
  tags = "fuzzing,ubuntu"
}