###### Fuzzing Tools Role (roles/fuzzing_tools/tasks/main.yml)
```yaml
---
- name: Install Python fuzzing dependencies
  apt:
    name:
      - python3-dev
      - python3-venv
      - libssl-dev
      - libffi-dev
    state: present