##### Install Ansible
```bash
# Install Ansible on management VM
sudo apt update
sudo apt install -y ansible python3-pip
pip3 install proxmoxer requests