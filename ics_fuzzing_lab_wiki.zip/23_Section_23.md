- name: Configure OpenDNP3
      command: cmake .. -DDNP3_ALL=ON
      args:
        chdir: /opt/simulators/dnp3/build
      become_user: ubuntu