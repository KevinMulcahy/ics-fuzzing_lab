- name: Clone and build OpenDNP3
  block:
    - name: Clone OpenDNP3 repository
      git:
        repo: https://github.com/automatak/dnp3.git
        dest: /opt/simulators/dnp3
        recursive: yes
      become_user: ubuntu