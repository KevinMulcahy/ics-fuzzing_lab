# Install Kibana
sudo apt install -y kibana
sudo systemctl enable kibana.service
sudo systemctl start kibana.service