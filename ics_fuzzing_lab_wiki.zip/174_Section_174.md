Analysis Network (virbr3 - 10.3.0.0/24)
├── Reverse Engineering VMs (10.3.0.10-19)
└── Malware Analysis (isolated)
```