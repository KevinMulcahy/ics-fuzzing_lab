### Access Controls
```bash
# Create dedicated lab user accounts
sudo useradd -m -s /bin/bash labadmin
sudo useradd -m -s /bin/bash researcher
sudo useradd -m -s /bin/bash analyst