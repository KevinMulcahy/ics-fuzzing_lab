- name: Create build directory
      file:
        path: /opt/simulators/dnp3/build
        state: directory
        owner: ubuntu
        group: ubuntu