##### Access Web Interface
```bash
# Access via browser: https://[SERVER-IP]:8006
# Default login: root / [password set during installation]