output "monitoring_ip" {
  description = "IP addresses of monitoring VM"
  value = {
    management = proxmox_vm_qemu.monitoring.default_ipv4_address
    fuzzing    = "10.1.0.40"
    simulation = "10.2.0.40"
    analysis   = "10.3.0.40"
  }
}