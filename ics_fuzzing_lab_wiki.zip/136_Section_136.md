# Install boofuzz
pip install boofuzz