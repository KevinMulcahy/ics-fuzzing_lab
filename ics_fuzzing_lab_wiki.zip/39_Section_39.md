- name: Configure log rotation for fuzzing logs
  template:
    src: fuzzing-logrotate.j2
    dest: /etc/logrotate.d/fuzzing-lab
```