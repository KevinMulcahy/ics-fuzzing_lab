- name: Create fuzzing tools directory
  file:
    path: /opt/fuzzing
    state: directory
    owner: ubuntu
    group: ubuntu
    mode: '0755'