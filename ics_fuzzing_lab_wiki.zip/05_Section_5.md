- name: Set up SSH keys
  authorized_key:
    user: ubuntu
    key: "{{ ssh_public_key }}"
    state: present