- name: Configure timezone
  timezone:
    name: America/New_York