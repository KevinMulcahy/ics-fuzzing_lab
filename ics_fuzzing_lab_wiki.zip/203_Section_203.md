# Test network bridges
echo "Bridge Status:"
ip link show | grep vmbr
```