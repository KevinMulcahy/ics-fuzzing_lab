# Protocol Simulator VMs
resource "proxmox_vm_qemu" "protocol_simulators" {
  count       = 2
  name        = "protocol-sim-${format("%02d", count.index + 1)}"
  target_node = "pve-fuzzing-01"
  vmid        = 201 + count.index
  
  clone    = var.vm_template
  os_type  = "cloud-init"
  cores    = 4
  memory   = 4096
  
  disk {
    slot    = "scsi0"
    size    = "50G"
    type    = "scsi"
    storage = "local-lvm"
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr0"
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr2"
    tag    = 20
  }
  
  ciuser     = "ubuntu"
  cipassword = "fuzzing123"
  sshkeys    = var.ssh_public_key
  ipconfig0  = "ip=10.0.0.${20 + count.index}/24,gw=10.0.0.1"
  ipconfig1  = "ip=10.2.0.${10 + count.index}/24"
  
  tags = "simulation,ubuntu"
}