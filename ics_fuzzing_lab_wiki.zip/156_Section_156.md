# Clone and install firmware-mod-kit
git clone https://github.com/rampageX/firmware-mod-kit.git
cd firmware-mod-kit/src
./configure && make
```