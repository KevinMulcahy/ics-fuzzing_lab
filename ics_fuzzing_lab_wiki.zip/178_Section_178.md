virsh net-define /tmp/simulation-net.xml
virsh net-start simulation-net
virsh net-autostart simulation-net
```