##### Weekly Snapshots
```bash
#!/bin/bash  
# weekly-snapshots.sh