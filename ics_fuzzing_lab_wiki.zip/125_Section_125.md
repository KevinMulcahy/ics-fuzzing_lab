##### Dynamic Inventory from Terraform
```python
#!/usr/bin/env python3
# terraform_inventory.py