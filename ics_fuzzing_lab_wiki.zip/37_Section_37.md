- name: Start and enable ELK services
  systemd:
    name: "{{ item }}"
    state: started
    enabled: yes
  loop:
    - elasticsearch
    - kibana
    - logstash