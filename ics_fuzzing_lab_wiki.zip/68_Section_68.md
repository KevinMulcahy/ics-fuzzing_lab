### Dell PowerEdge R430 (Primary Fuzzing Server) - Proxmox Node 1
```bash
# Install Proxmox VE 8.x
# Recommended partitioning:
# /boot/efi - 512MB (UEFI)
# / (root) - 50GB
# swap - 16GB (equal to RAM for hibernation)
# Remaining space for VM storage (LVM-thin or ZFS)