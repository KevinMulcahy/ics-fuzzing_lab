- name: Install network monitoring tools
  apt:
    name:
      - tcpdump
      - wireshark-common
      - tshark
      - nmap
      - netstat-nat
    state: present