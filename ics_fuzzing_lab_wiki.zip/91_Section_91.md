# Get cluster join information
pvecm status
```