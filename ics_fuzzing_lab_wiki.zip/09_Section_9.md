- name: Install Boofuzz
  pip:
    name: boofuzz
    virtualenv: /opt/fuzzing/boofuzz-env
    virtualenv_python: python3
  become_user: ubuntu