- name: Install Logstash
  apt:
    name: logstash
    state: present