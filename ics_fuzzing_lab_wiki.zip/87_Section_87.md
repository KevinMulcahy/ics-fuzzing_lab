# CLI method:
pvesm add dir fuzzing-lab --path /var/lib/vz/fuzzing-lab --content images,vztmpl,backup
mkdir -p /var/lib/vz/fuzzing-lab
```