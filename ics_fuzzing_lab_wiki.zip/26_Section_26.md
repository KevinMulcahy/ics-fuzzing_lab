- name: Configure simulator services
  template:
    src: "{{ item.src }}"
    dest: "/etc/systemd/system/{{ item.dest }}"
    mode: '0644'
  loop:
    - { src: 'modbuspal.service.j2', dest: 'modbuspal.service' }
    - { src: 'dnp3-sim.service.j2', dest: 'dnp3-sim.service' }
  notify: reload systemd