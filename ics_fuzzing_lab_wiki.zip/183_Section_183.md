# Default policies
sudo ufw default deny incoming
sudo ufw default allow outgoing