- name: Configure reverse engineering systems
  hosts: reverse_engineering
  become: yes
  roles:
    - reverse_engineering