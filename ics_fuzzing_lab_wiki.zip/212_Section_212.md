# Test Scapy
python3 -c "import scapy; print('✓ Scapy OK')" 2>/dev/null || echo "✗ Scapy FAIL"
```