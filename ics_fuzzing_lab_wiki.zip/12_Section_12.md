- name: Install AFL++
      make:
        chdir: /opt/fuzzing/AFLplusplus
        target: install
      become: yes