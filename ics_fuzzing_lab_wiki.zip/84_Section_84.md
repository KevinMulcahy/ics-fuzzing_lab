# Update package lists
apt update
```