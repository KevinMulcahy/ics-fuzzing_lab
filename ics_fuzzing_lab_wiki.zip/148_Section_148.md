#### Install OpenDNP3
```bash
# Install dependencies
sudo apt install -y cmake build-essential