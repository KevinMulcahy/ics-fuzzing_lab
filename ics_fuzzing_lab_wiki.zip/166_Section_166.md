# Install Scapy
sudo apt install -y python3-scapy