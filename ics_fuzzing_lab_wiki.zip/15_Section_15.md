- name: Create fuzzing scripts
  template:
    src: "{{ item.src }}"
    dest: "/opt/fuzzing/{{ item.dest }}"
    mode: '0755'
    owner: ubuntu
    group: ubuntu
  loop:
    - { src: 'start-boofuzz.sh.j2', dest: 'start-boofuzz.sh' }
    - { src: 'run-afl.sh.j2', dest: 'run-afl.sh' }
    - { src: 'fuzz-modbus.py.j2', dest: 'fuzz-modbus.py' }