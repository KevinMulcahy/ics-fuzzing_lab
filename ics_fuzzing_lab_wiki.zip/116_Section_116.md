##### Deployment Commands
```bash
# Initialize Terraform
terraform init