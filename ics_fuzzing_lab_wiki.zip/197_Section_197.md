#### Proxmox Connectivity Test
```bash
#!/bin/bash
# test-proxmox-connectivity.sh