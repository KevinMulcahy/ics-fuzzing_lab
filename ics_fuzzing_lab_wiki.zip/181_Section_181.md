# Configure sudo access
echo "labadmin ALL=(ALL) ALL" | sudo tee /etc/sudoers.d/labadmin
echo "researcher ALL=(ALL) NOPASSWD: /usr/bin/virsh" | sudo tee /etc/sudoers.d/researcher
```