# Test AFL++
afl-fuzz -h >/dev/null 2>&1 && echo "✓ AFL++ OK" || echo "✗ AFL++ FAIL"