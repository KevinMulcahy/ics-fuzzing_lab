# Reverse Engineering VM
resource "proxmox_vm_qemu" "reverse_engineering" {
  name        = "reverse-eng-01"
  target_node = "pve-analysis-01"
  vmid        = 301
  
  clone    = var.vm_template
  os_type  = "cloud-init"
  cores    = 8
  memory   = 32768
  
  disk {
    slot    = "scsi0"
    size    = "200G"
    type    = "scsi"
    storage = "local-lvm"
  }
  
  network {
    model  = "virtio"
    bridge = "vmbr3"
    tag    = 30
  }
  
  ciuser     = "ubuntu"
  cipassword = "fuzzing123"
  sshkeys    = var.ssh_public_key
  ipconfig0  = "ip=10.3.0.10/24"
  
  tags = "analysis,ubuntu"
}