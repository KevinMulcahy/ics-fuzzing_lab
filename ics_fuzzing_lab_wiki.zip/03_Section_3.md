- name: Install common packages
  apt:
    name:
      - curl
      - wget
      - git
      - vim
      - htop
      - iotop
      - tmux
      - python3
      - python3-pip
      - build-essential
    state: present