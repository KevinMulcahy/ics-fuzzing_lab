virsh net-define /tmp/fuzzing-net.xml
virsh net-start fuzzing-net
virsh net-autostart fuzzing-net