###### Monitoring Role (roles/monitoring/tasks/main.yml)
```yaml
---
- name: Install Java for ELK stack
  apt:
    name: openjdk-11-jdk
    state: present