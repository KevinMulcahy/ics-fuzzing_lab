# Update and install
apt update && apt full-upgrade
apt install proxmox-ve postfix open-iscsi