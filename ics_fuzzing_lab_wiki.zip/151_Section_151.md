#### Install Ghidra
```bash
# Install Java JDK
sudo apt install -y openjdk-17-jdk