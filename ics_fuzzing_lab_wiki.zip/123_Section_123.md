# Install Ansible collections
ansible-galaxy collection install community.general
ansible-galaxy collection install ansible.posix
```