# Enable firewall
sudo ufw enable
```