# Check backup jobs
echo "Recent Backups:"
cat /var/log/vzdump.log | tail -20
```