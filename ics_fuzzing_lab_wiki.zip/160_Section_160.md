# Install Elasticsearch
sudo apt update
sudo apt install -y elasticsearch