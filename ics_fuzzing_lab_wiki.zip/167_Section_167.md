# Install additional network tools
sudo apt install -y wireshark-common tshark tcpdump netcat nmap