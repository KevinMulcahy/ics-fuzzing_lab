# Create pcap directory structure
mkdir -p ~/pcaps/{original,modified,output}
```