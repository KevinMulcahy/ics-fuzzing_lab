# Install dependencies
sudo apt install -y python2.7 python-pip
pip install -r requirements.txt