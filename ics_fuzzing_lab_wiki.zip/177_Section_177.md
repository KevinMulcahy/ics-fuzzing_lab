# Create simulation network
cat << 'EOF' > /tmp/simulation-net.xml
<network>
  <name>simulation-net</name>
  <forward mode='none'/>
  <bridge name='virbr2' stp='on' delay='0'/>
  <ip address='10.2.0.1' netmask='255.255.255.0'>
  </ip>
</network>
EOF