- name: Configure monitoring system
  hosts: monitoring
  become: yes
  roles:
    - monitoring