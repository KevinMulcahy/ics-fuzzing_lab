```
Management Network (virbr0)
├── Management VM (192.168.122.10)
├── Monitoring VM (192.168.122.20)
└── Jump Host Access