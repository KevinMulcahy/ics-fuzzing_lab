# Test installation
python3 -c "import boofuzz; print('Boofuzz installed successfully')"
```