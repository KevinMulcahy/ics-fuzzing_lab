### Prerequisites
- [ ] Dell PowerEdge R430 server
- [ ] Dell PowerEdge R730 server
- [ ] Network switches/infrastructure
- [ ] Adequate power and cooling
- [ ] Remote access capabilities (iDRAC)